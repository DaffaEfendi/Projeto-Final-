import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.security.sasl.SaslException;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws SaslException, IOException {
        String usernameOrEmail = request.getParameter("usernameOrEmail");
        String password = request.getParameter("password");

        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection con = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=seu_banco_de_dados", "seu_usuario", "sua_senha");

            String query = "SELECT * FROM users WHERE (username = ? OR email = ?) AND password = ?";
            try (PreparedStatement pst = con.prepareStatement(query)) {
                pst.setString(1, usernameOrEmail);
                pst.setString(2, usernameOrEmail);
                pst.setString(3, password);

                ResultSet rs = pst.executeQuery();

                if (rs.next()) {
                    HttpSession session = request.getSession();
                    session.setAttribute("username", rs.getString("username"));
                    response.sendRedirect("home.jsp");
                } else {
                    response.sendRedirect("login.jsp");
                }

                rs.close();
            }

            con.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            // Trate as exceções de acordo com suas necessidades
        }
    }
}
