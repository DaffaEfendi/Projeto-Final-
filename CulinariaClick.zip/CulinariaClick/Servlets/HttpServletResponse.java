
public class HttpServletResponse {

    public void sendRedirect(String string) {
    }

}
