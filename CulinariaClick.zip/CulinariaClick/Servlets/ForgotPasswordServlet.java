import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/ForgotPasswordServlet")
public class ForgotPasswordServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        String email = request.getParameter("email");

        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection con = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=seu_banco_de_dados", "seu_usuario", "sua_senha");

            String query = "SELECT * FROM users WHERE email = ?";
            try (PreparedStatement pst = con.prepareStatement(query)) {
                pst.setString(1, email);

                ResultSet rs = pst.executeQuery();

                if (rs.next()) {
                    // Lógica de recuperação de senha
                    // Envio de e-mail, etc.
                    response.sendRedirect("passwordRecovery.jsp");
                } else {
                    response.sendRedirect("forgotPassword.jsp");
                }

                rs.close();
            }

            con.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            // Trate as exceções de acordo com suas necessidades
            // Redirecione para uma página de erro ou faça algo apropriado
            response.sendRedirect("error.jsp");
        }
    }
}
