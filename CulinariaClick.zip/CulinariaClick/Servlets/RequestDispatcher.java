
public class RequestDispatcher {

    public void forward(HttpServletRequest request, HttpServletResponse response) {
    }

}
