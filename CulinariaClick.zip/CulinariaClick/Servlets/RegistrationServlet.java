import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.security.sasl.SaslException;

@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws SaslException, IOException {
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String dobDay = request.getParameter("dobDay");
        String dobMonth = request.getParameter("dobMonth");
        String dobYear = request.getParameter("dobYear");

        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection con = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=seu_banco_de_dados", "seu_usuario", "sua_senha");

            String query = "INSERT INTO users (username, email, password, dob) VALUES (?, ?, ?, ?)";
            try (PreparedStatement pst = con.prepareStatement(query)) {
                pst.setString(1, username);
                pst.setString(2, email);
                pst.setString(3, password);
                pst.setString(4, dobYear + "-" + dobMonth + "-" + dobDay);

                int numRowsAffected = pst.executeUpdate();

                if (numRowsAffected > 0) {
                    response.sendRedirect("login.jsp");
                } else {
                    response.sendRedirect("registration.jsp");
                }
            }

            con.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            // Trate as exceções de acordo com suas necessidades
        }
    }
}
