import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/SearchRecipeServlet")
public class SearchRecipeServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException, IOException {
        String searchInput = request.getParameter("searchInput");

        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection con = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=seu_banco_de_dados", "seu_usuario", "sua_senha");

            String query = "SELECT * FROM recipes WHERE name LIKE ? OR ingredients LIKE ?";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, "%" + searchInput + "%");
            pst.setString(2, "%" + searchInput + "%");

            ResultSet rs = pst.executeQuery();

            List<Recipe> recipes = new ArrayList<>();

            while (rs.next()) {
                Recipe recipe = new Recipe();
                recipe.setId(rs.getInt("id"));
                recipe.setName(rs.getString("name"));
                recipe.setDescription(rs.getString("description"));
                // Adicione mais campos conforme necessário

                recipes.add(recipe);
            }

            request.setAttribute("recipes", recipes);
            RequestDispatcher dispatcher = (RequestDispatcher) request.getRequestDispatcher("searchResult.jsp");
            dispatcher.forward(request, response);

            rs.close();
            pst.close();
            con.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            // Trate as exceções de acordo com suas necessidades
        }
    }
}
