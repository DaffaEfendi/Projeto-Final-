
public @interface WebServlet {

    String value();

}
