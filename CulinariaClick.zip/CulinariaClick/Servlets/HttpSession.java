
public class HttpSession {

    public void setAttribute(String string, String string2) {
    }

}
