import java.util.List;

public class HttpServletRequest {

   

    public HttpSession getSession() {
        return null;
    }

    public String getParameter(String string) {
        return null;
    }

    public void setAttribute(String string, List<Recipe> recipes) {
    }

    public Object getRequestDispatcher(String string) {
        return null;
    }

}
